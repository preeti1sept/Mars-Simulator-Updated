package com.ove.simulator;

public class Coordinates {

	private int xAxis;
	private int yAxis;
	
	public Coordinates(int xAxis, int yAxis){
		this.xAxis = xAxis;
		this.yAxis = yAxis;
	}

	public int getxAxis() {
		return xAxis;
	}

	public int getyAxis() {
		return yAxis;
	}
}
